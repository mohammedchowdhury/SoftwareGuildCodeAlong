var trafficLightColor = "green";

switch(trafficLightColor){
    case "red":
        console.log("STOP");
        break;
    case "yellow":
        console.log("SLOW DOWN");
        break;
    default:
        console.log("GO!!!!");
}





/**********************************
 * The Software Guild
 * Copyright (C) 2019 Wiley edu LLC - All Rights Reserved
 *********************************/