var trafficLightColor = "green";

if (trafficLightColor == "red"){
    console.log("STOP");
} else if (trafficLightColor == "yellow") {
    console.log("SLOW DOWN");
} else {
    console.log("GO!!!!");
}





/**********************************
 * The Software Guild
 * Copyright (C) 2019 Wiley edu LLC - All Rights Reserved
 *********************************/