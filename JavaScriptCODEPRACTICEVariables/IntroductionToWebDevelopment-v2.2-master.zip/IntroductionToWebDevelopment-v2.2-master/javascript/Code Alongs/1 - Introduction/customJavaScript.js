// This is part of the Introduction to Web Development lesson

var total = 0;
var firstNumber = 2;
var secondNumber = 3;
 
total = firstNumber + secondNumber;
 
console.log(total);

/**********************************
 * The Software Guild
 * Copyright (C) 2019 Wiley edu LLC - All Rights Reserved
 *********************************/