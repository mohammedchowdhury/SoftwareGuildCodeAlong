var integerNumberVariable = 42;
var floatNumberVariable = 3.14;
var stringVariable = "This is a string.";
var stringVariable2 = 'This is a string too!';
var stringVariable3 = 'c'; // this is a char in other languages
var booleanVariable = true;
var nullVariable = null;
var undefinedVariable;




/**********************************
 * The Software Guild
 * Copyright (C) 2019 Wiley edu LLC - All Rights Reserved
 *********************************/